import Foundation

enum NumericInput {
    private static let groupingCharacters = [",", "，", " ", "\u{00A0}", "\u{202F}"]

    static func normalized(_ value: String) -> String {
        groupingCharacters.reduce(value.trimmingCharacters(in: .whitespacesAndNewlines)) {
            $0.replacingOccurrences(of: $1, with: "")
        }
    }

    static func integer(from value: String) -> Int? {
        let normalizedValue = normalized(value)
        if let integer = Int(normalizedValue) { return integer }
        guard let double = Double(normalizedValue), double.isFinite else { return nil }
        return Int(double.rounded())
    }

    static func double(from value: String) -> Double? {
        guard let result = Double(normalized(value)), result.isFinite else { return nil }
        return result
    }

    static func formattedDouble(_ value: Double) -> String {
        var result = String(format: "%.8f", locale: Locale(identifier: "en_US_POSIX"), value)
        while result.last == "0" { result.removeLast() }
        if result.last == "." { result.removeLast() }
        return result == "-0" ? "0" : result
    }
}
import simd

enum ContentMode: String, Codable, CaseIterable {
    case fit
    case fill
    case stretch

    var title: String {
        switch self {
        case .fit: return "完整显示"
        case .fill: return "铺满裁切"
        case .stretch: return "拉伸铺满"
        }
    }

    var shaderValue: Int32 {
        switch self {
        case .fit: return 0
        case .fill: return 1
        case .stretch: return 2
        }
    }
}

struct NormalizedRect: Codable, Equatable {
    var x: Double
    var y: Double
    var width: Double
    var height: Double

    static let full = NormalizedRect(x: 0, y: 0, width: 1, height: 1)

    func sanitized() -> NormalizedRect {
        let safeX = min(max(x, 0), 0.999)
        let safeY = min(max(y, 0), 0.999)
        return NormalizedRect(
            x: safeX,
            y: safeY,
            width: min(max(width, 0.001), 1 - safeX),
            height: min(max(height, 0.001), 1 - safeY)
        )
    }
}

struct CanvasConfiguration: Codable, Equatable {
    var width: Int
    var height: Int

    var aspect: Float { Float(width) / Float(max(height, 1)) }
}

struct MirrorConfiguration: Codable, Equatable {
    var horizontal = false
    var vertical = false
}

struct ManualWarpParameters: Codable, Equatable {
    var enabled = true
    var strength = 1.0
    var arch = 0.105
    var verticalScale = 0.83
    var asymmetry = 0.08
    var tilt = 0.025
    var horizontalBend = 0.018
}

struct PolynomialTerm: Equatable {
    let xPower: Int
    let yPower: Int

    var label: String {
        if xPower == 0 && yPower == 0 { return "1" }
        var parts = [String]()
        if xPower > 0 { parts.append(xPower == 1 ? "x" : "x^\(xPower)") }
        if yPower > 0 { parts.append(yPower == 1 ? "y" : "y^\(yPower)") }
        return parts.joined(separator: "·")
    }
}

struct PolynomialWarpConfiguration: Codable, Equatable {
    var enabled = false
    var order = 3
    var coefficientsX = Array(repeating: 0.0, count: 10)
    var coefficientsY = Array(repeating: 0.0, count: 10)

    static func terms(order: Int) -> [PolynomialTerm] {
        let safeOrder = min(max(order, 2), 5)
        var result = [PolynomialTerm]()
        for degree in 0...safeOrder {
            for yPower in 0...degree {
                result.append(PolynomialTerm(xPower: degree - yPower, yPower: yPower))
            }
        }
        return result
    }

    static func coefficientCount(order: Int) -> Int {
        terms(order: order).count
    }

    func evaluate(x: Double, y: Double, coefficients: [Double]) -> Double {
        zip(Self.terms(order: order), coefficients).reduce(0) { partial, pair in
            partial + pair.1 * pow(x, Double(pair.0.xPower)) * pow(y, Double(pair.0.yPower))
        }
    }

    func normalized() -> PolynomialWarpConfiguration {
        var copy = self
        copy.order = min(max(order, 2), 5)
        let count = Self.coefficientCount(order: copy.order)
        copy.coefficientsX = Array(coefficientsX.prefix(count)) + Array(repeating: 0, count: max(0, count - coefficientsX.count))
        copy.coefficientsY = Array(coefficientsY.prefix(count)) + Array(repeating: 0, count: max(0, count - coefficientsY.count))
        return copy
    }
}

struct WarpConfiguration: Codable, Equatable {
    static let currentSchemaVersion = 2

    var schemaVersion = currentSchemaVersion
    var displayPixelWidth: Int
    var displayPixelHeight: Int
    var aaRect: NormalizedRect
    var canvas: CanvasConfiguration
    var mirror = MirrorConfiguration()
    var contentMode = ContentMode.stretch
    var manual = ManualWarpParameters()
    var polynomial = PolynomialWarpConfiguration()

    static func defaultConfiguration(displayWidth: Int, displayHeight: Int) -> WarpConfiguration {
        WarpConfiguration(
            displayPixelWidth: displayWidth,
            displayPixelHeight: displayHeight,
            aaRect: NormalizedRect(x: 0.06, y: 0.26, width: 0.88, height: 0.48),
            canvas: CanvasConfiguration(width: 7680, height: 936)
        )
    }

    func sanitized(forDisplayWidth width: Int, height: Int) -> WarpConfiguration {
        var copy = self
        if copy.schemaVersion < 2 {
            let usesLegacyDefaultAA = abs(copy.aaRect.x - 0.06) < 0.000_001
                && abs(copy.aaRect.y - 0.18) < 0.000_001
                && abs(copy.aaRect.width - 0.88) < 0.000_001
                && abs(copy.aaRect.height - 0.48) < 0.000_001
            if usesLegacyDefaultAA {
                copy.aaRect.y = 0.26
                if copy.contentMode == .fit { copy.contentMode = .stretch }
            }
        }
        copy.schemaVersion = Self.currentSchemaVersion
        copy.displayPixelWidth = width
        copy.displayPixelHeight = height
        copy.aaRect = copy.aaRect.sanitized()
        copy.canvas.width = min(max(copy.canvas.width, 64), 32768)
        copy.canvas.height = min(max(copy.canvas.height, 64), 32768)
        copy.manual.strength = min(max(copy.manual.strength, 0), 2)
        copy.manual.verticalScale = min(max(copy.manual.verticalScale, 0.2), 2)
        copy.polynomial = copy.polynomial.normalized()
        return copy
    }

    func validationErrors() -> [String] {
        var errors = [String]()
        if schemaVersion < 1 || schemaVersion > Self.currentSchemaVersion {
            errors.append("不支持的 schemaVersion：\(schemaVersion)")
        }
        if displayPixelWidth <= 0 || displayPixelHeight <= 0 { errors.append("显示器像素尺寸必须大于 0") }
        if canvas.width <= 0 || canvas.height <= 0 { errors.append("画布尺寸必须大于 0") }
        if aaRect != aaRect.sanitized() { errors.append("AA 区必须完全位于屏幕归一化范围内") }
        let normalizedPolynomial = polynomial.normalized()
        if polynomial.order != normalizedPolynomial.order { errors.append("多项式阶数仅支持 2–5 阶") }
        let expected = PolynomialWarpConfiguration.coefficientCount(order: normalizedPolynomial.order)
        if polynomial.coefficientsX.count != expected || polynomial.coefficientsY.count != expected {
            errors.append("\(normalizedPolynomial.order) 阶多项式的 X/Y 系数必须各有 \(expected) 项")
        }
        if polynomial.coefficientsX.contains(where: { !$0.isFinite }) || polynomial.coefficientsY.contains(where: { !$0.isFinite }) {
            errors.append("多项式系数不能包含 NaN 或 Infinity")
        }
        return errors
    }
}

final class ConfigurationStore {
    private let key = "nioWarpConfiguration.v1"
    private let defaults: UserDefaults
    private let encoder: JSONEncoder
    private let decoder = JSONDecoder()

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
    }

    func load(displayWidth: Int, displayHeight: Int) -> WarpConfiguration {
        guard let data = defaults.data(forKey: key),
              let configuration = try? decoder.decode(WarpConfiguration.self, from: data) else {
            let configuration = WarpConfiguration.defaultConfiguration(displayWidth: displayWidth, displayHeight: displayHeight)
            save(configuration)
            return configuration
        }
        let sanitized = configuration.sanitized(forDisplayWidth: displayWidth, height: displayHeight)
        if sanitized != configuration { save(sanitized) }
        return sanitized
    }

    func save(_ configuration: WarpConfiguration) {
        guard let data = try? encoder.encode(configuration) else { return }
        defaults.set(data, forKey: key)
    }

    func exportData(_ configuration: WarpConfiguration) throws -> Data {
        try encoder.encode(configuration)
    }

    func importData(
        _ data: Data,
        baseConfiguration: WarpConfiguration? = nil,
        displayWidth: Int,
        displayHeight: Int
    ) throws -> WarpConfiguration {
        if let decoded = try? decoder.decode(WarpConfiguration.self, from: data) {
            let errors = decoded.validationErrors()
            guard errors.isEmpty else {
                throw NSError(domain: "NIOWarp.Configuration", code: 1, userInfo: [NSLocalizedDescriptionKey: errors.joined(separator: "\n")])
            }
            return decoded.sanitized(forDisplayWidth: displayWidth, height: displayHeight)
        }

        if let polynomial = try? decoder.decode(PolynomialWarpConfiguration.self, from: data) {
            let normalized = polynomial.normalized()
            guard polynomial.order == normalized.order,
                  polynomial.coefficientsX.count == normalized.coefficientsX.count,
                  polynomial.coefficientsY.count == normalized.coefficientsY.count,
                  !polynomial.coefficientsX.contains(where: { !$0.isFinite }),
                  !polynomial.coefficientsY.contains(where: { !$0.isFinite }) else {
                throw NSError(domain: "NIOWarp.Configuration", code: 2, userInfo: [NSLocalizedDescriptionKey: "多项式文件的阶数、系数数量或数值无效"])
            }
            var configuration = baseConfiguration ?? .defaultConfiguration(displayWidth: displayWidth, displayHeight: displayHeight)
            configuration.polynomial = normalized
            return configuration.sanitized(forDisplayWidth: displayWidth, height: displayHeight)
        }

        throw NSError(domain: "NIOWarp.Configuration", code: 3, userInfo: [NSLocalizedDescriptionKey: "文件既不是完整 Warp 配置，也不是多项式配置"])
    }
}
