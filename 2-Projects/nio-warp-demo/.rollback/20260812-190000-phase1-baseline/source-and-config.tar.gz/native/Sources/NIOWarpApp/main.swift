import AppKit
import CoreGraphics
import CoreMedia
import CoreVideo
import Foundation
import Metal
import MetalKit
import ScreenCaptureKit

private struct ShaderUniforms {
    var sourceAspect: Float
    var canvasAspect: Float
    var contentMode: Int32
    var mirrorFlags: UInt32
}

private final class LatestFrameStore {
    private let lock = NSLock()
    private var pixelBuffer: CVPixelBuffer?

    func update(_ buffer: CVPixelBuffer) {
        lock.lock()
        pixelBuffer = buffer
        lock.unlock()
    }

    func latest() -> CVPixelBuffer? {
        lock.lock()
        defer { lock.unlock() }
        return pixelBuffer
    }
}

private final class CaptureEngine: NSObject, SCStreamOutput, SCStreamDelegate {
    let frameStore = LatestFrameStore()
    private let queue = DispatchQueue(label: "com.mycc.nio-warp.capture", qos: .userInteractive)
    private var stream: SCStream?
    var onError: ((String) -> Void)?

    func start(displayID: CGDirectDisplayID) async throws {
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: false)
        guard let display = content.displays.first(where: { $0.displayID == displayID }) else {
            throw NSError(domain: "NIOWarp", code: 1, userInfo: [NSLocalizedDescriptionKey: "无法找到源显示器"])
        }

        let currentBundleID = Bundle.main.bundleIdentifier
        let excludedApplications = content.applications.filter { application in
            application.bundleIdentifier == currentBundleID
        }
        let filter = SCContentFilter(
            display: display,
            excludingApplications: excludedApplications,
            exceptingWindows: []
        )
        let configuration = SCStreamConfiguration()
        configuration.width = display.width
        configuration.height = display.height
        configuration.pixelFormat = kCVPixelFormatType_32BGRA
        configuration.minimumFrameInterval = CMTime(value: 1, timescale: 60)
        configuration.queueDepth = 3
        configuration.showsCursor = false
        configuration.capturesAudio = false
        configuration.scalesToFit = false

        let stream = SCStream(filter: filter, configuration: configuration, delegate: self)
        try stream.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
        self.stream = stream
        try await stream.startCapture()
    }

    func stop() async {
        guard let stream else { return }
        try? await stream.stopCapture()
        self.stream = nil
    }

    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of outputType: SCStreamOutputType) {
        guard outputType == .screen,
              sampleBuffer.isValid,
              let imageBuffer = sampleBuffer.imageBuffer else { return }
        frameStore.update(imageBuffer)
    }

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        DispatchQueue.main.async { [weak self] in
            self?.onError?(error.localizedDescription)
        }
    }
}

private final class WarpRenderer: NSObject, MTKViewDelegate {
    private let device: MTLDevice
    private let commandQueue: MTLCommandQueue
    private let pipeline: MTLRenderPipelineState
    private var textureCache: CVMetalTextureCache?
    private let frameStore: LatestFrameStore
    private var vertexBuffer: MTLBuffer?
    private var indexBuffer: MTLBuffer?
    private var indexCount = 0
    private var configuration: WarpConfiguration
    private(set) var meshValidation = MeshValidation(foldedCellCount: 0, outOfAASampleCount: 0, totalSampleCount: 0)

    init?(view: MTKView, frameStore: LatestFrameStore, configuration: WarpConfiguration) {
        guard let device = MTLCreateSystemDefaultDevice(),
              let commandQueue = device.makeCommandQueue() else { return nil }
        self.device = device
        self.commandQueue = commandQueue
        self.frameStore = frameStore
        self.configuration = configuration

        let shaderSource = """
        #include <metal_stdlib>
        using namespace metal;

        struct VertexIn {
            float2 position [[attribute(0)]];
            float2 uv [[attribute(1)]];
        };

        struct VertexOut {
            float4 position [[position]];
            float2 uv;
        };

        struct Uniforms {
            float sourceAspect;
            float canvasAspect;
            int contentMode;
            uint mirrorFlags;
        };

        vertex VertexOut vertexMain(VertexIn input [[stage_in]]) {
            VertexOut output;
            output.position = float4(input.position, 0.0, 1.0);
            output.uv = input.uv;
            return output;
        }

        fragment float4 fragmentMain(
            VertexOut input [[stage_in]],
            texture2d<float> source [[texture(0)]],
            constant Uniforms& uniforms [[buffer(1)]]) {
            constexpr sampler textureSampler(filter::linear, address::clamp_to_zero);
            float2 uv = input.uv;

            if (uniforms.contentMode == 0) {
                if (uniforms.sourceAspect < uniforms.canvasAspect) {
                    float visibleWidth = uniforms.sourceAspect / uniforms.canvasAspect;
                    uv.x = (uv.x - (1.0 - visibleWidth) * 0.5) / visibleWidth;
                } else {
                    float visibleHeight = uniforms.canvasAspect / uniforms.sourceAspect;
                    uv.y = (uv.y - (1.0 - visibleHeight) * 0.5) / visibleHeight;
                }
            } else if (uniforms.contentMode == 1) {
                if (uniforms.sourceAspect < uniforms.canvasAspect) {
                    float sampledHeight = uniforms.sourceAspect / uniforms.canvasAspect;
                    uv.y = uv.y * sampledHeight + (1.0 - sampledHeight) * 0.5;
                } else {
                    float sampledWidth = uniforms.canvasAspect / uniforms.sourceAspect;
                    uv.x = uv.x * sampledWidth + (1.0 - sampledWidth) * 0.5;
                }
            }

            if ((uniforms.mirrorFlags & 1u) != 0u) { uv.x = 1.0 - uv.x; }
            if ((uniforms.mirrorFlags & 2u) != 0u) { uv.y = 1.0 - uv.y; }
            if (any(uv < 0.0) || any(uv > 1.0)) {
                return float4(0.0, 0.0, 0.0, 1.0);
            }
            return source.sample(textureSampler, uv);
        }
        """

        do {
            let library = try device.makeLibrary(source: shaderSource, options: nil)
            let descriptor = MTLRenderPipelineDescriptor()
            descriptor.vertexFunction = library.makeFunction(name: "vertexMain")
            descriptor.fragmentFunction = library.makeFunction(name: "fragmentMain")
            descriptor.colorAttachments[0].pixelFormat = .bgra8Unorm

            let vertexDescriptor = MTLVertexDescriptor()
            vertexDescriptor.attributes[0].format = .float2
            vertexDescriptor.attributes[0].offset = 0
            vertexDescriptor.attributes[0].bufferIndex = 0
            vertexDescriptor.attributes[1].format = .float2
            vertexDescriptor.attributes[1].offset = MemoryLayout<SIMD2<Float>>.stride
            vertexDescriptor.attributes[1].bufferIndex = 0
            vertexDescriptor.layouts[0].stride = MemoryLayout<MeshVertex>.stride
            descriptor.vertexDescriptor = vertexDescriptor
            pipeline = try device.makeRenderPipelineState(descriptor: descriptor)
        } catch {
            return nil
        }

        super.init()
        view.device = device
        view.colorPixelFormat = .bgra8Unorm
        view.clearColor = MTLClearColorMake(0, 0, 0, 1)
        view.preferredFramesPerSecond = 60
        view.enableSetNeedsDisplay = false
        view.isPaused = false
        view.framebufferOnly = true
        CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, device, nil, &textureCache)
        rebuildMesh()
    }

    @discardableResult
    func updateConfiguration(_ configuration: WarpConfiguration) -> MeshValidation {
        self.configuration = configuration
        rebuildMesh()
        return meshValidation
    }

    private func rebuildMesh() {
        let mesh = WarpMath.makeMesh(configuration: configuration)
        vertexBuffer = device.makeBuffer(
            bytes: mesh.vertices,
            length: mesh.vertices.count * MemoryLayout<MeshVertex>.stride
        )
        indexBuffer = device.makeBuffer(
            bytes: mesh.indices,
            length: mesh.indices.count * MemoryLayout<UInt32>.stride
        )
        indexCount = mesh.indices.count
        meshValidation = mesh.validation
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

    func draw(in view: MTKView) {
        guard let pixelBuffer = frameStore.latest(),
              let descriptor = view.currentRenderPassDescriptor,
              let drawable = view.currentDrawable,
              let commandBuffer = commandQueue.makeCommandBuffer(),
              let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: descriptor),
              let vertexBuffer,
              let indexBuffer,
              let textureCache else { return }

        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        var cvTexture: CVMetalTexture?
        let status = CVMetalTextureCacheCreateTextureFromImage(
            kCFAllocatorDefault,
            textureCache,
            pixelBuffer,
            nil,
            .bgra8Unorm,
            width,
            height,
            0,
            &cvTexture
        )
        guard status == kCVReturnSuccess,
              let cvTexture,
              let texture = CVMetalTextureGetTexture(cvTexture) else { return }

        var mirrorFlags: UInt32 = 0
        if configuration.mirror.horizontal { mirrorFlags |= 1 }
        if configuration.mirror.vertical { mirrorFlags |= 2 }
        var uniforms = ShaderUniforms(
            sourceAspect: Float(width) / Float(height),
            canvasAspect: configuration.canvas.aspect,
            contentMode: configuration.contentMode.shaderValue,
            mirrorFlags: mirrorFlags
        )

        let aa = configuration.aaRect.sanitized()
        let drawableWidth = max(Int(view.drawableSize.width), 1)
        let drawableHeight = max(Int(view.drawableSize.height), 1)
        let scissorX = min(max(Int((aa.x * Double(drawableWidth)).rounded()), 0), drawableWidth - 1)
        let scissorY = min(max(Int((aa.y * Double(drawableHeight)).rounded()), 0), drawableHeight - 1)
        let scissorWidth = min(max(Int((aa.width * Double(drawableWidth)).rounded()), 1), drawableWidth - scissorX)
        let scissorHeight = min(max(Int((aa.height * Double(drawableHeight)).rounded()), 1), drawableHeight - scissorY)

        encoder.setRenderPipelineState(pipeline)
        encoder.setScissorRect(MTLScissorRect(x: scissorX, y: scissorY, width: scissorWidth, height: scissorHeight))
        encoder.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
        encoder.setFragmentTexture(texture, index: 0)
        encoder.setFragmentBytes(&uniforms, length: MemoryLayout<ShaderUniforms>.stride, index: 1)
        encoder.drawIndexedPrimitives(
            type: .triangle,
            indexCount: indexCount,
            indexType: .uint32,
            indexBuffer: indexBuffer,
            indexBufferOffset: 0
        )
        encoder.endEncoding()
        commandBuffer.present(drawable)
        commandBuffer.addCompletedHandler { _ in _ = cvTexture }
        commandBuffer.commit()
    }
}

private final class OutputWindow: NSWindow {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}

private final class FlippedView: NSView {
    override var isFlipped: Bool { true }
}

private enum NumericFieldTarget: Int {
    case aaX
    case aaY
    case aaWidth
    case aaHeight
    case canvasWidth
    case canvasHeight
    case coefficientX
    case coefficientY
}

private final class OutputController {
    let window: NSWindow
    let renderer: WarpRenderer

    init?(screen: NSScreen, frameStore: LatestFrameStore, configuration: WarpConfiguration) {
        let window = OutputWindow(
            contentRect: screen.frame,
            styleMask: [.borderless],
            backing: .buffered,
            defer: false,
            screen: screen
        )
        window.backgroundColor = .black
        window.isOpaque = true
        window.hasShadow = false
        window.collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle]
        window.level = .screenSaver
        window.ignoresMouseEvents = true
        window.hidesOnDeactivate = false

        let metalView = MTKView(frame: NSRect(origin: .zero, size: screen.frame.size))
        metalView.autoresizingMask = [.width, .height]
        guard let renderer = WarpRenderer(view: metalView, frameStore: frameStore, configuration: configuration) else { return nil }
        metalView.delegate = renderer
        window.contentView = metalView
        window.setFrame(screen.frame, display: true)
        window.orderFrontRegardless()

        self.window = window
        self.renderer = renderer
    }
}

private final class ControlPanelController: NSWindowController, NSTextFieldDelegate {
    private let renderer: WarpRenderer
    private let store: ConfigurationStore
    private let displayWidth: Int
    private let displayHeight: Int
    private var configuration: WarpConfiguration

    private let statusLabel = NSTextField(wrappingLabelWithString: "等待屏幕捕获权限…")
    private let aaXField = NSTextField()
    private let aaYField = NSTextField()
    private let aaWidthField = NSTextField()
    private let aaHeightField = NSTextField()
    private let canvasWidthField = NSTextField()
    private let canvasHeightField = NSTextField()
    private let horizontalMirrorButton = NSButton(checkboxWithTitle: "水平翻转", target: nil, action: nil)
    private let verticalMirrorButton = NSButton(checkboxWithTitle: "垂直翻转", target: nil, action: nil)
    private let warpButton = NSButton(checkboxWithTitle: "启用基础 Warp", target: nil, action: nil)
    private let polynomialButton = NSButton(checkboxWithTitle: "启用多项式增量", target: nil, action: nil)
    private let orderPicker = NSPopUpButton()
    private let termPicker = NSPopUpButton()
    private let coefficientXField = NSTextField()
    private let coefficientYField = NSTextField()
    private let contentModePicker = NSPopUpButton()
    private let strengthSlider = NSSlider()
    private let archSlider = NSSlider()
    private let verticalScaleSlider = NSSlider()
    private let asymmetrySlider = NSSlider()
    private let tiltSlider = NSSlider()
    private let horizontalBendSlider = NSSlider()

    init(
        renderer: WarpRenderer,
        store: ConfigurationStore,
        configuration: WarpConfiguration,
        sourceScreen: NSScreen,
        outputScreen: NSScreen
    ) {
        self.renderer = renderer
        self.store = store
        self.configuration = configuration
        displayWidth = configuration.displayPixelWidth
        displayHeight = configuration.displayPixelHeight
        let panel = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 560, height: 790),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        panel.title = "NIO 全屏 Warp 标定控制台"
        panel.level = .floating
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        super.init(window: panel)
        buildInterface(sourceScreen: sourceScreen, outputScreen: outputScreen)
        refreshControls()
        panel.center()
        bringToFront()
    }

    required init?(coder: NSCoder) { nil }

    private func buildInterface(sourceScreen: NSScreen, outputScreen: NSScreen) {
        guard let contentView = window?.contentView else { return }
        let scrollView = NSScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.hasVerticalScroller = true
        scrollView.drawsBackground = false
        contentView.addSubview(scrollView)
        NSLayoutConstraint.activate([
            scrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            scrollView.topAnchor.constraint(equalTo: contentView.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
        ])

        let documentView = FlippedView()
        documentView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.documentView = documentView
        documentView.widthAnchor.constraint(equalTo: scrollView.contentView.widthAnchor).isActive = true

        let stack = NSStackView()
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 12
        stack.edgeInsets = NSEdgeInsets(top: 20, left: 22, bottom: 22, right: 22)
        stack.translatesAutoresizingMaskIntoConstraints = false
        documentView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: documentView.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: documentView.trailingAnchor),
            stack.topAnchor.constraint(equalTo: documentView.topAnchor),
            stack.bottomAnchor.constraint(equalTo: documentView.bottomAnchor),
        ])

        let title = NSTextField(labelWithString: "外屏桌面 → 逻辑画布 → 预畸变 → 矩形 AA 区")
        title.font = .systemFont(ofSize: 18, weight: .bold)
        stack.addArrangedSubview(title)
        let topology = NSTextField(wrappingLabelWithString: "源：\(screenName(sourceScreen))\n输出：\(screenName(outputScreen)) · \(displayWidth)×\(displayHeight) px\nAA 区外始终纯黑；多项式定义为逻辑画布到物理 AA 区的增量映射。")
        topology.textColor = .secondaryLabelColor
        stack.addArrangedSubview(topology)

        stack.addArrangedSubview(sectionTitle("1. 矩形 AA 区（物理屏像素）"))
        stack.addArrangedSubview(fieldGrid([
            ("X", numericField(aaXField, target: .aaX, decimal: false)),
            ("Y", numericField(aaYField, target: .aaY, decimal: false)),
            ("宽", numericField(aaWidthField, target: .aaWidth, decimal: false)),
            ("高", numericField(aaHeightField, target: .aaHeight, decimal: false)),
        ]))
        stack.addArrangedSubview(buttonRow([
            makeButton("保存并应用 AA 区", action: #selector(applyAAFields)),
            makeButton("居中 88%×48%", action: #selector(centerAA)),
            makeButton("全屏 AA", action: #selector(fullAA)),
        ]))

        stack.addArrangedSubview(sectionTitle("2. 逻辑画布"))
        stack.addArrangedSubview(fieldGrid([
            ("宽", numericField(canvasWidthField, target: .canvasWidth, decimal: false)),
            ("高", numericField(canvasHeightField, target: .canvasHeight, decimal: false)),
        ]))
        ContentMode.allCases.forEach { contentModePicker.addItem(withTitle: $0.title) }
        contentModePicker.target = self
        contentModePicker.action = #selector(updateContentMode)
        stack.addArrangedSubview(labeledRow("内容适配", contentModePicker))
        stack.addArrangedSubview(makeButton("保存并应用画布尺寸", action: #selector(applyCanvasFields)))

        stack.addArrangedSubview(sectionTitle("3. 镜像"))
        horizontalMirrorButton.target = self
        horizontalMirrorButton.action = #selector(updateMirror)
        verticalMirrorButton.target = self
        verticalMirrorButton.action = #selector(updateMirror)
        stack.addArrangedSubview(buttonRow([horizontalMirrorButton, verticalMirrorButton]))

        stack.addArrangedSubview(sectionTitle("4. 基础校畸变"))
        warpButton.target = self
        warpButton.action = #selector(toggleWarp)
        stack.addArrangedSubview(warpButton)
        stack.addArrangedSubview(makeSlider(title: "Warp 强度", slider: strengthSlider, minimum: 0, maximum: 1.5, action: #selector(updateStrength)))
        stack.addArrangedSubview(makeSlider(title: "上下弧度", slider: archSlider, minimum: 0, maximum: 0.2, action: #selector(updateArch)))
        stack.addArrangedSubview(makeSlider(title: "垂直压缩", slider: verticalScaleSlider, minimum: 0.6, maximum: 1.1, action: #selector(updateVerticalScale)))
        stack.addArrangedSubview(makeSlider(title: "左右不对称", slider: asymmetrySlider, minimum: -0.2, maximum: 0.2, action: #selector(updateAsymmetry)))
        stack.addArrangedSubview(makeSlider(title: "整体倾斜", slider: tiltSlider, minimum: -0.12, maximum: 0.12, action: #selector(updateTilt)))
        stack.addArrangedSubview(makeSlider(title: "水平弯曲", slider: horizontalBendSlider, minimum: -0.08, maximum: 0.08, action: #selector(updateHorizontalBend)))

        stack.addArrangedSubview(sectionTitle("5. 多项式增量"))
        polynomialButton.target = self
        polynomialButton.action = #selector(togglePolynomial)
        stack.addArrangedSubview(polynomialButton)
        for order in 2...5 { orderPicker.addItem(withTitle: "\(order) 阶") }
        orderPicker.target = self
        orderPicker.action = #selector(updatePolynomialOrder)
        stack.addArrangedSubview(labeledRow("阶数", orderPicker))
        termPicker.target = self
        termPicker.action = #selector(selectPolynomialTerm)
        stack.addArrangedSubview(labeledRow("当前项", termPicker))
        stack.addArrangedSubview(fieldGrid([
            ("X 系数", numericField(coefficientXField, target: .coefficientX, decimal: true)),
            ("Y 系数", numericField(coefficientYField, target: .coefficientY, decimal: true)),
        ]))
        stack.addArrangedSubview(buttonRow([
            makeButton("应用当前系数", action: #selector(applyPolynomialCoefficients)),
            makeButton("全部系数清零", action: #selector(clearPolynomial)),
        ]))

        stack.addArrangedSubview(sectionTitle("6. 配置"))
        stack.addArrangedSubview(buttonRow([
            makeButton("导入 JSON", action: #selector(importConfiguration)),
            makeButton("导出 JSON", action: #selector(exportConfiguration)),
            makeButton("恢复默认", action: #selector(resetConfiguration)),
        ]))

        statusLabel.textColor = .systemOrange
        statusLabel.maximumNumberOfLines = 5
        statusLabel.preferredMaxLayoutWidth = 500
        stack.addArrangedSubview(statusLabel)

        let hint = NSTextField(wrappingLabelWithString: "注意：当前是视觉接管。覆盖层鼠标穿透，但 Warp 后的视觉坐标尚未做输入逆映射。JSON 配置可以用于后续真实玻璃标定。")
        hint.textColor = .secondaryLabelColor
        stack.addArrangedSubview(hint)
        stack.addArrangedSubview(makeButton("退出 Warp", action: #selector(NSApplication.terminate(_:)), target: NSApp))
    }

    private func screenName(_ screen: NSScreen) -> String {
        "\(screen.localizedName) · \(Int(screen.frame.width))×\(Int(screen.frame.height)) pt"
    }

    private func sectionTitle(_ title: String) -> NSTextField {
        let label = NSTextField(labelWithString: title)
        label.font = .systemFont(ofSize: 14, weight: .bold)
        return label
    }

    private func makeButton(_ title: String, action: Selector, target: AnyObject? = nil) -> NSButton {
        NSButton(title: title, target: target ?? self, action: action)
    }

    private func buttonRow(_ views: [NSView]) -> NSStackView {
        let row = NSStackView(views: views)
        row.orientation = .horizontal
        row.spacing = 8
        return row
    }

    private func labeledRow(_ title: String, _ view: NSView) -> NSStackView {
        let label = NSTextField(labelWithString: title)
        label.widthAnchor.constraint(equalToConstant: 92).isActive = true
        let row = NSStackView(views: [label, view])
        row.orientation = .horizontal
        row.spacing = 8
        return row
    }

    private func fieldGrid(_ fields: [(String, NSView)]) -> NSGridView {
        let rows = fields.chunked(into: 2).map { group -> [NSView] in
            var views = [NSView]()
            for item in group {
                let label = NSTextField(labelWithString: item.0)
                views.append(label)
                views.append(item.1)
            }
            while views.count < 4 { views.append(NSView()) }
            return views
        }
        let grid = NSGridView(views: rows)
        grid.rowSpacing = 8
        grid.columnSpacing = 8
        return grid
    }

    private func numericField(_ field: NSTextField, target: NumericFieldTarget, decimal: Bool) -> NSView {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.usesGroupingSeparator = false
        formatter.allowsFloats = decimal
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = decimal ? 8 : 0
        field.formatter = formatter
        field.alignment = .right
        field.widthAnchor.constraint(equalToConstant: 92).isActive = true

        let minus = makeButton("−", action: #selector(adjustNumericField(_:)))
        minus.tag = target.rawValue * 2
        minus.widthAnchor.constraint(equalToConstant: 28).isActive = true
        let plus = makeButton("+", action: #selector(adjustNumericField(_:)))
        plus.tag = target.rawValue * 2 + 1
        plus.widthAnchor.constraint(equalToConstant: 28).isActive = true

        let row = NSStackView(views: [minus, field, plus])
        row.orientation = .horizontal
        row.spacing = 4
        return row
    }

    private func makeSlider(title: String, slider: NSSlider, minimum: Double, maximum: Double, action: Selector) -> NSView {
        let container = NSStackView()
        container.orientation = .vertical
        container.alignment = .leading
        container.spacing = 4
        let label = NSTextField(labelWithString: title)
        label.font = .systemFont(ofSize: 12, weight: .semibold)
        slider.minValue = minimum
        slider.maxValue = maximum
        slider.target = self
        slider.action = action
        slider.isContinuous = true
        slider.widthAnchor.constraint(equalToConstant: 490).isActive = true
        container.addArrangedSubview(label)
        container.addArrangedSubview(slider)
        return container
    }

    private func refreshControls() {
        let aa = configuration.aaRect.sanitized()
        aaXField.stringValue = String(Int((aa.x * Double(displayWidth)).rounded()))
        aaYField.stringValue = String(Int((aa.y * Double(displayHeight)).rounded()))
        aaWidthField.stringValue = String(Int((aa.width * Double(displayWidth)).rounded()))
        aaHeightField.stringValue = String(Int((aa.height * Double(displayHeight)).rounded()))
        canvasWidthField.stringValue = String(configuration.canvas.width)
        canvasHeightField.stringValue = String(configuration.canvas.height)
        horizontalMirrorButton.state = configuration.mirror.horizontal ? .on : .off
        verticalMirrorButton.state = configuration.mirror.vertical ? .on : .off
        warpButton.state = configuration.manual.enabled ? .on : .off
        polynomialButton.state = configuration.polynomial.enabled ? .on : .off
        strengthSlider.doubleValue = configuration.manual.strength
        archSlider.doubleValue = configuration.manual.arch
        verticalScaleSlider.doubleValue = configuration.manual.verticalScale
        asymmetrySlider.doubleValue = configuration.manual.asymmetry
        tiltSlider.doubleValue = configuration.manual.tilt
        horizontalBendSlider.doubleValue = configuration.manual.horizontalBend
        contentModePicker.selectItem(at: ContentMode.allCases.firstIndex(of: configuration.contentMode) ?? 0)
        orderPicker.selectItem(at: configuration.polynomial.order - 2)
        rebuildTermPicker()
    }

    private func rebuildTermPicker() {
        let previous = max(termPicker.indexOfSelectedItem, 0)
        termPicker.removeAllItems()
        PolynomialWarpConfiguration.terms(order: configuration.polynomial.order).forEach { term in
            termPicker.addItem(withTitle: term.label)
        }
        termPicker.selectItem(at: min(previous, max(termPicker.numberOfItems - 1, 0)))
        refreshCoefficientFields()
    }

    private func refreshCoefficientFields() {
        let index = max(termPicker.indexOfSelectedItem, 0)
        let polynomial = configuration.polynomial.normalized()
        coefficientXField.stringValue = NumericInput.formattedDouble(polynomial.coefficientsX[index])
        coefficientYField.stringValue = NumericInput.formattedDouble(polynomial.coefficientsY[index])
    }

    private func applyConfiguration(_ message: String) {
        configuration = configuration.sanitized(forDisplayWidth: displayWidth, height: displayHeight)
        store.save(configuration)
        let validation = renderer.updateConfiguration(configuration)
        let color: NSColor = validation.isValid ? .systemGreen : .systemRed
        setStatus("\(message)；\(validation.summary)", color: color)
    }

    func setStatus(_ text: String, color: NSColor = .systemGreen) {
        statusLabel.stringValue = text
        statusLabel.textColor = color
    }

    func bringToFront() {
        guard let window else { return }
        window.orderFrontRegardless()
        window.makeKey()
    }

    @objc private func applyAAFields() {
        let aa = configuration.aaRect.sanitized()
        let currentX = Int((aa.x * Double(displayWidth)).rounded())
        let currentY = Int((aa.y * Double(displayHeight)).rounded())
        let currentWidth = Int((aa.width * Double(displayWidth)).rounded())
        let currentHeight = Int((aa.height * Double(displayHeight)).rounded())
        configuration.aaRect = NormalizedRect(
            x: Double(NumericInput.integer(from: aaXField.stringValue) ?? currentX) / Double(displayWidth),
            y: Double(NumericInput.integer(from: aaYField.stringValue) ?? currentY) / Double(displayHeight),
            width: Double(NumericInput.integer(from: aaWidthField.stringValue) ?? currentWidth) / Double(displayWidth),
            height: Double(NumericInput.integer(from: aaHeightField.stringValue) ?? currentHeight) / Double(displayHeight)
        )
        applyConfiguration("AA 区已应用")
        refreshControls()
    }

    @objc private func centerAA() {
        configuration.aaRect = NormalizedRect(x: 0.06, y: 0.26, width: 0.88, height: 0.48)
        applyConfiguration("AA 区已居中")
        refreshControls()
    }

    @objc private func fullAA() {
        configuration.aaRect = .full
        applyConfiguration("AA 区已设为全屏")
        refreshControls()
    }

    @objc private func applyCanvasFields() {
        configuration.canvas.width = NumericInput.integer(from: canvasWidthField.stringValue) ?? configuration.canvas.width
        configuration.canvas.height = NumericInput.integer(from: canvasHeightField.stringValue) ?? configuration.canvas.height
        applyConfiguration("画布尺寸已应用")
        refreshControls()
    }

    @objc private func updateContentMode() {
        configuration.contentMode = ContentMode.allCases[contentModePicker.indexOfSelectedItem]
        applyConfiguration("内容适配已更新")
    }

    @objc private func updateMirror() {
        configuration.mirror.horizontal = horizontalMirrorButton.state == .on
        configuration.mirror.vertical = verticalMirrorButton.state == .on
        applyConfiguration("镜像已更新")
    }

    @objc private func toggleWarp() {
        configuration.manual.enabled = warpButton.state == .on
        applyConfiguration("基础 Warp 已更新")
    }

    @objc private func updateStrength(_ sender: NSSlider) { configuration.manual.strength = sender.doubleValue; applyConfiguration("Warp 强度已更新") }
    @objc private func updateArch(_ sender: NSSlider) { configuration.manual.arch = sender.doubleValue; applyConfiguration("上下弧度已更新") }
    @objc private func updateVerticalScale(_ sender: NSSlider) { configuration.manual.verticalScale = sender.doubleValue; applyConfiguration("垂直压缩已更新") }
    @objc private func updateAsymmetry(_ sender: NSSlider) { configuration.manual.asymmetry = sender.doubleValue; applyConfiguration("左右不对称已更新") }
    @objc private func updateTilt(_ sender: NSSlider) { configuration.manual.tilt = sender.doubleValue; applyConfiguration("整体倾斜已更新") }
    @objc private func updateHorizontalBend(_ sender: NSSlider) { configuration.manual.horizontalBend = sender.doubleValue; applyConfiguration("水平弯曲已更新") }

    @objc private func togglePolynomial() {
        configuration.polynomial.enabled = polynomialButton.state == .on
        applyConfiguration("多项式增量已更新")
    }

    @objc private func updatePolynomialOrder() {
        configuration.polynomial.order = orderPicker.indexOfSelectedItem + 2
        configuration.polynomial = configuration.polynomial.normalized()
        rebuildTermPicker()
        applyConfiguration("多项式阶数已更新")
    }

    @objc private func selectPolynomialTerm() { refreshCoefficientFields() }

    @objc private func applyPolynomialCoefficients() {
        let index = max(termPicker.indexOfSelectedItem, 0)
        configuration.polynomial = configuration.polynomial.normalized()
        configuration.polynomial.coefficientsX[index] = NumericInput.double(from: coefficientXField.stringValue)
            ?? configuration.polynomial.coefficientsX[index]
        configuration.polynomial.coefficientsY[index] = NumericInput.double(from: coefficientYField.stringValue)
            ?? configuration.polynomial.coefficientsY[index]
        applyConfiguration("多项式系数已应用")
        refreshCoefficientFields()
    }

    @objc private func adjustNumericField(_ sender: NSButton) {
        guard let target = NumericFieldTarget(rawValue: sender.tag / 2) else { return }
        let direction = sender.tag.isMultiple(of: 2) ? -1.0 : 1.0

        switch target {
        case .aaX:
            adjustIntegerField(aaXField, delta: Int(direction), minimum: 0, maximum: displayWidth - 1)
            applyAAFields()
        case .aaY:
            adjustIntegerField(aaYField, delta: Int(direction), minimum: 0, maximum: displayHeight - 1)
            applyAAFields()
        case .aaWidth:
            adjustIntegerField(aaWidthField, delta: Int(direction), minimum: 1, maximum: displayWidth)
            applyAAFields()
        case .aaHeight:
            adjustIntegerField(aaHeightField, delta: Int(direction), minimum: 1, maximum: displayHeight)
            applyAAFields()
        case .canvasWidth:
            adjustIntegerField(canvasWidthField, delta: Int(direction), minimum: 64, maximum: 32768)
            applyCanvasFields()
        case .canvasHeight:
            adjustIntegerField(canvasHeightField, delta: Int(direction), minimum: 64, maximum: 32768)
            applyCanvasFields()
        case .coefficientX:
            adjustDoubleField(coefficientXField, delta: direction * 0.001)
            applyPolynomialCoefficients()
        case .coefficientY:
            adjustDoubleField(coefficientYField, delta: direction * 0.001)
            applyPolynomialCoefficients()
        }
    }

    private func adjustIntegerField(_ field: NSTextField, delta: Int, minimum: Int, maximum: Int) {
        let value = NumericInput.integer(from: field.stringValue) ?? minimum
        field.stringValue = String(min(max(value + delta, minimum), maximum))
    }

    private func adjustDoubleField(_ field: NSTextField, delta: Double) {
        let value = NumericInput.double(from: field.stringValue) ?? 0
        field.stringValue = NumericInput.formattedDouble(value + delta)
    }

    @objc private func clearPolynomial() {
        let count = PolynomialWarpConfiguration.coefficientCount(order: configuration.polynomial.order)
        configuration.polynomial.coefficientsX = Array(repeating: 0, count: count)
        configuration.polynomial.coefficientsY = Array(repeating: 0, count: count)
        refreshCoefficientFields()
        applyConfiguration("多项式系数已清零")
    }

    @objc private func importConfiguration() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.json]
        panel.allowsMultipleSelection = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let data = try Data(contentsOf: url)
            configuration = try store.importData(
                data,
                baseConfiguration: configuration,
                displayWidth: displayWidth,
                displayHeight: displayHeight
            )
            refreshControls()
            applyConfiguration("配置已导入：\(url.lastPathComponent)")
        } catch {
            setStatus("导入失败：\(error.localizedDescription)", color: .systemRed)
        }
    }

    @objc private func exportConfiguration() {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.json]
        panel.nameFieldStringValue = "nio-warp-configuration.json"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            try store.exportData(configuration).write(to: url, options: .atomic)
            setStatus("配置已导出：\(url.path)")
        } catch {
            setStatus("导出失败：\(error.localizedDescription)", color: .systemRed)
        }
    }

    @objc private func resetConfiguration() {
        configuration = .defaultConfiguration(displayWidth: displayWidth, displayHeight: displayHeight)
        refreshControls()
        applyConfiguration("已恢复默认配置")
    }
}

private extension Array {
    func chunked(into size: Int) -> [[Element]] {
        stride(from: 0, to: count, by: size).map { Array(self[$0..<Swift.min($0 + size, count)]) }
    }
}

private final class AppDelegate: NSObject, NSApplicationDelegate {
    private let captureEngine = CaptureEngine()
    private let configurationStore = ConfigurationStore()
    private var outputController: OutputController?
    private var controlPanel: ControlPanelController?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        guard let topology = chooseScreens(),
              let outputID = displayID(for: topology.output) else {
            showFatal("需要同时连接 MacBook 内置屏和一台外接显示器。")
            return
        }
        let displayMode = CGDisplayCopyDisplayMode(outputID)
        let pixelWidth = displayMode?.pixelWidth ?? CGDisplayPixelsWide(outputID)
        let pixelHeight = displayMode?.pixelHeight ?? CGDisplayPixelsHigh(outputID)
        let configuration = configurationStore.load(displayWidth: pixelWidth, displayHeight: pixelHeight)
        guard let outputController = OutputController(
            screen: topology.output,
            frameStore: captureEngine.frameStore,
            configuration: configuration
        ) else {
            showFatal("无法初始化 Metal 输出。")
            return
        }
        self.outputController = outputController
        let controlPanel = ControlPanelController(
            renderer: outputController.renderer,
            store: configurationStore,
            configuration: configuration,
            sourceScreen: topology.source,
            outputScreen: topology.output
        )
        self.controlPanel = controlPanel
        NSApp.activate(ignoringOtherApps: true)
        controlPanel.bringToFront()
        captureEngine.onError = { [weak controlPanel] message in
            controlPanel?.setStatus("捕获中断：\(message)", color: .systemRed)
        }

        guard CGPreflightScreenCaptureAccess() else {
            _ = CGRequestScreenCaptureAccess()
            outputController.window.orderOut(nil)
            controlPanel.setStatus(
                "请在系统设置 → 隐私与安全性 → 屏幕与系统音频录制中允许 NIOWarpApp，然后退出并重新启动。",
                color: .systemOrange
            )
            NSApp.activate(ignoringOtherApps: true)
            controlPanel.bringToFront()
            return
        }

        Task {
            do {
                try await captureEngine.start(displayID: outputID)
                await MainActor.run {
                    controlPanel.setStatus("正在捕获外屏完整桌面；AA 区外纯黑，配置会自动保存。")
                    NSApp.activate(ignoringOtherApps: true)
                    controlPanel.bringToFront()
                }
            } catch {
                await MainActor.run {
                    controlPanel.setStatus("启动失败：\(error.localizedDescription)", color: .systemRed)
                }
            }
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        Task { await captureEngine.stop() }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    private func chooseScreens() -> (source: NSScreen, output: NSScreen)? {
        let screens = NSScreen.screens
        guard screens.count >= 2 else { return nil }
        let builtIn = screens.first(where: { screen in
            guard let id = displayID(for: screen) else { return false }
            return CGDisplayIsBuiltin(id) != 0
        }) ?? NSScreen.main ?? screens[0]
        let output = screens
            .filter { $0 !== builtIn }
            .max { lhs, rhs in lhs.frame.width * lhs.frame.height < rhs.frame.width * rhs.frame.height }
        guard let output else { return nil }
        return (output, output)
    }

    private func displayID(for screen: NSScreen) -> CGDirectDisplayID? {
        screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? CGDirectDisplayID
    }

    private func showFatal(_ message: String) {
        let alert = NSAlert()
        alert.messageText = "NIO Warp 无法启动"
        alert.informativeText = message
        alert.alertStyle = .critical
        alert.runModal()
        NSApp.terminate(nil)
    }
}

let application = NSApplication.shared
private let appDelegate = AppDelegate()
application.delegate = appDelegate
application.run()
