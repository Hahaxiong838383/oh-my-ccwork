import XCTest
@testable import NIOWarpApp

final class WarpConfigurationTests: XCTestCase {
    func testNumericInputParsesGroupedIntegersWithoutTruncation() {
        XCTAssertEqual(NumericInput.integer(from: "4,405"), 4405)
        XCTAssertEqual(NumericInput.integer(from: "7，680"), 7680)
        XCTAssertEqual(NumericInput.integer(from: " 2 880 "), 2880)
    }

    func testNumericInputParsesAndFormatsDecimalValues() {
        XCTAssertEqual(NumericInput.double(from: "-0.00150000"), -0.0015)
        XCTAssertEqual(NumericInput.formattedDouble(-0.0015), "-0.0015")
        XCTAssertEqual(NumericInput.formattedDouble(0), "0")
    }

    func testPolynomialTermCounts() {
        XCTAssertEqual(PolynomialWarpConfiguration.coefficientCount(order: 2), 6)
        XCTAssertEqual(PolynomialWarpConfiguration.coefficientCount(order: 3), 10)
        XCTAssertEqual(PolynomialWarpConfiguration.coefficientCount(order: 5), 21)
    }

    func testPolynomialEvaluationUsesDocumentedTermOrder() {
        var polynomial = PolynomialWarpConfiguration()
        polynomial.order = 2
        polynomial.coefficientsX = [1, 2, 3, 4, 5, 6]
        let value = polynomial.evaluate(x: 2, y: 3, coefficients: polynomial.coefficientsX)
        let expected = 1.0 + 4.0 + 9.0 + 16.0 + 30.0 + 54.0
        XCTAssertEqual(value, expected, accuracy: 0.000_001)
    }

    func testAARectSanitizesInsideDisplay() {
        let rect = NormalizedRect(x: -0.2, y: 0.9, width: 1.4, height: 0.8).sanitized()
        XCTAssertEqual(rect.x, 0)
        XCTAssertEqual(rect.y, 0.9)
        XCTAssertEqual(rect.width, 1)
        XCTAssertEqual(rect.height, 0.1, accuracy: 0.000_001)
    }

    func testDefaultMeshHasNoFoldedCells() {
        let configuration = WarpConfiguration.defaultConfiguration(displayWidth: 5120, displayHeight: 2880)
        XCTAssertEqual(configuration.contentMode, .stretch)
        XCTAssertEqual(configuration.aaRect.y, 0.26)
        let mesh = WarpMath.makeMesh(configuration: configuration, columns: 32, rows: 16)
        XCTAssertEqual(mesh.validation.foldedCellCount, 0)
        XCTAssertEqual(mesh.vertices.count, 33 * 17)
        XCTAssertEqual(mesh.indices.count, 32 * 16 * 6)
    }

    func testPolynomialCanMovePhysicalMesh() {
        var configuration = WarpConfiguration.defaultConfiguration(displayWidth: 5120, displayHeight: 2880)
        configuration.manual.enabled = false
        configuration.polynomial.enabled = true
        configuration.polynomial.order = 2
        configuration.polynomial = configuration.polynomial.normalized()
        configuration.polynomial.coefficientsX[0] = 0.1
        let point = WarpMath.localPhysicalPoint(canvasPoint: SIMD2<Float>(0.5, 0.5), configuration: configuration)
        XCTAssertEqual(point.x, 0.6, accuracy: 0.000_001)
        XCTAssertEqual(point.y, 0.5, accuracy: 0.000_001)
    }

    func testConfigurationJSONRoundTrip() throws {
        let suiteName = "NIOWarpAppTests.\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }
        let store = ConfigurationStore(defaults: defaults)
        var configuration = WarpConfiguration.defaultConfiguration(displayWidth: 5120, displayHeight: 2880)
        configuration.mirror.horizontal = true
        configuration.polynomial.enabled = true
        let data = try store.exportData(configuration)
        let decoded = try store.importData(data, displayWidth: 5120, displayHeight: 2880)
        XCTAssertEqual(decoded, configuration)
    }

    func testLegacyConfigurationMigratesToVersionTwoDefaults() {
        var configuration = WarpConfiguration.defaultConfiguration(displayWidth: 5120, displayHeight: 2880)
        configuration.schemaVersion = 1
        configuration.aaRect = NormalizedRect(x: 0.06, y: 0.18, width: 0.88, height: 0.48)
        configuration.contentMode = .fit
        let migrated = configuration.sanitized(forDisplayWidth: 5120, height: 2880)
        XCTAssertEqual(migrated.schemaVersion, 2)
        XCTAssertEqual(migrated.aaRect.y, 0.26)
        XCTAssertEqual(migrated.contentMode, .stretch)
    }

    func testLegacyCustomFitConfigurationIsPreserved() {
        var configuration = WarpConfiguration.defaultConfiguration(displayWidth: 5120, displayHeight: 2880)
        configuration.schemaVersion = 1
        configuration.aaRect = NormalizedRect(x: 0.1, y: 0.2, width: 0.7, height: 0.4)
        configuration.contentMode = .fit
        let migrated = configuration.sanitized(forDisplayWidth: 5120, height: 2880)
        XCTAssertEqual(migrated.contentMode, .fit)
        XCTAssertEqual(migrated.aaRect, configuration.aaRect)
    }

    func testPolynomialOnlyJSONImport() throws {
        let suiteName = "NIOWarpAppTests.\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }
        let store = ConfigurationStore(defaults: defaults)
        var polynomial = PolynomialWarpConfiguration()
        polynomial.enabled = true
        polynomial.coefficientsX[0] = 0.05
        let data = try JSONEncoder().encode(polynomial)
        let base = WarpConfiguration.defaultConfiguration(displayWidth: 5120, displayHeight: 2880)
        let imported = try store.importData(data, baseConfiguration: base, displayWidth: 5120, displayHeight: 2880)
        XCTAssertTrue(imported.polynomial.enabled)
        XCTAssertEqual(imported.polynomial.coefficientsX[0], 0.05)
        XCTAssertEqual(imported.canvas, base.canvas)
    }

    func testFirstLoadPersistsDefaultConfiguration() throws {
        let suiteName = "NIOWarpAppTests.\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }
        let store = ConfigurationStore(defaults: defaults)
        let configuration = store.load(displayWidth: 5120, displayHeight: 2880)
        XCTAssertNotNil(defaults.data(forKey: "nioWarpConfiguration.v1"))
        XCTAssertEqual(configuration.canvas, CanvasConfiguration(width: 7680, height: 936))
        XCTAssertEqual(configuration.contentMode, .stretch)
    }
}
